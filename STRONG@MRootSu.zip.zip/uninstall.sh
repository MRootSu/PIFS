#!/system/bin/sh
rm -rf /data/adb/tricky_store/