##########################################################################################
#
# MMT Extended Config Script
#
##########################################################################################

##########################################################################################
# Config Flags
##########################################################################################

# Uncomment and change 'MINAPI' and 'MAXAPI' to the minimum and maximum android version for your mod
# Uncomment DYNLIB if you want libs installed to vendor for oreo+ and system for anything older
# Uncomment PARTOVER if you have a workaround in place for extra partitions in regular magisk install (can mount them yourself - you will need to do this each boot as well). If unsure, keep commented
# Uncomment PARTITIONS and list additional partitions you will be modifying (other than system and vendor), for example: PARTITIONS="/odm /product /system_ext"
#MINAPI=21
#MAXAPI=25
#DYNLIB=true
#PARTOVER=true
#PARTITIONS=""

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info why you would need this

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE="
"

##########################################################################################
# Permissions
##########################################################################################

set_permissions() {
  : # Remove this if adding to this function

  # Note that all files/folders in magisk module directory have the $MODPATH prefix - keep this prefix on all of your files/folders
  # Some examples:
  
  # For directories (includes files in them):
  # set_perm_recursive  <dirname>                <owner> <group> <dirpermission> <filepermission> <contexts> (default: u:object_r:system_file:s0)
  set_perm  $MODPATH/system/bin/script  0  0  0755
  # set_perm_recursive $MODPATH/system/lib 0 0 0755 0644
  # set_perm_recursive $MODPATH/system/vendor/lib/soundfx 0 0 0755 0644

  # For files (not in directories taken care of above)
  # set_perm  <filename>                         <owner> <group> <permission> <contexts> (default: u:object_r:system_file:s0)
  
  # set_perm $MODPATH/system/lib/libart.so 0 0 0644
  # set_perm /data/local/tmp/file.txt 0 0 644
}

##########################################################################################
# MMT Extended Logic - Don't modify anything after this
##########################################################################################

SKIPUNZIP=1
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
. $TMPDIR/functions.sh

# End AdBlock Start Play Integrity Script ⭐
if [ "$API" -lt 26 ]; then
    abort "- !!! You can't use this module on Android < 8.0"
fi

# safetynet-fix module is obsolete and it's incompatible with PIF
if [ -d "/data/adb/modules/safetynet-fix" ]; then
    touch "/data/adb/modules/safetynet-fix/remove"
    ui_print "! safetynet-fix module removed. Do NOT install it again along PIF"
fi

# playcurl must be removed when flashing PIF
if [ -d "/data/adb/modules/playcurl" ]; then
    touch "/data/adb/modules/playcurl/remove"
    ui_print "! playcurl module removed!"
fi

# MagiskHidePropsConf module is obsolete in Android 8+ but it shouldn't give issues
if [ -d "/data/adb/modules/MagiskHidePropsConf" ]; then
    ui_print "! WARNING, MagiskHidePropsConf module may cause issues with PIF."
fi

# Check custom fingerprint
if [ -f "/data/adb/pif.json" ]; then
    mv -f "/data/adb/pif.json" "/data/adb/pif.json.old"
        ui_print "- Welcome "
fi

# End Play integrity Script ⭐

# Start Random KeyBox By @MRootSu ⭐
unzip -o "$ZIPFILE" '@MRootSu/*' -d "$MODPATH/@MRootSu" > /dev/null 2>&1

if [ -f "/data/adb/tricky_store/keybox.xml" ]; then
  backup_file "$CONFIG_DIR/keybox.xml"
  rm "/data/adb/tricky_store/keybox.xml"
fi
random_keybox=$(find "$MODPATH/@MRootSu" -type f -name "*.xml" | shuf -n 1)
if [ -z "$random_keybox" ]; then
    abort "Error: No .xml files found"
    exit 1
fi
cp "$random_keybox" "/data/adb/tricky_store/keybox.xml" 

su -c killall com.google.android.gms
su -c killall com.google.android.gms.unstable

# End Random KeyBox Script ⭐

# Start Change BusyBox Modules To Built-In BusyBox ⭐
if [ -d "/data/adb/modules/busybox-ndk" ]; then
    touch "/data/adb/modules/busybox-ndk/remove"
    ui_print
fi
# End Change BusyBox Script ⭐

# Start Auto Hide App Script ⭐
nohup am start -a android.intent.action.VIEW -d https://t.me/MRootOnline >/dev/null 2>&1 &
su -c "magisk --denylist add com.google.android.gms com.google.android.gms:snet"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms:identitycredentials"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms:car"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.unstable"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.ui"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.room"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.remapping1"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.persistent"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.learning"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.feedback"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms"
su -c "magisk --denylist add com.android.vending com.android.vending"
su -c "magisk --denylist add com.android.vending com.google.android.finsky.verifier.impl.ConsentDialog"
su -c "magisk --denylist add com.android.vending com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog"
su -c "magisk --denylist add com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog"
su -c "magisk --denylist add com.google.android.finsky.verifier.impl.ConsentDialog com.google.android.finsky.verifier.impl.ConsentDialog"
su -c "magisk --denylist add com.android.vending com.android.vending:background"
su -c "magisk --denylist add com.android.vending com.android.vending:instant_app_installer"
su -c "magisk --denylist add com.android.vending com.android.vending:com.google.android.finsky.verifier.apkanalysis.service.ApkContentsScanService"
su -c "magisk --denylist add com.android.vending com.android.vending:recovery_mode"
su -c "magisk --denylist add com.android.vending com.android.vending:quick_launch"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:gib"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:container"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:phoenix"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:playcore_missing_splits_activity"
su -c "magisk --denylist add com.BanqueMisr.MobileBanking com.BanqueMisr.MobileBanking"
su -c "magisk --denylist add com.CIB.Digital.MB com.CIB.Digital.MB"
su -c "magisk --denylist add com.egyptianbanks.instapay com.egyptianbanks.instapay"
su -c "magisk --denylist add sa.gov.nic.myid sa.gov.nic.myid"
su -c "magisk --denylist add com.stc com.stc"
su -c "magisk --denylist add com.etisalat.flous com.etisalat.flous"
su -c "magisk --denylist add com.ucare.we com.ucare.we"
su -c "magisk --denylist add com.ucare.we com.ucare.we:pushservice"
su -c "magisk --denylist add com.ofss.obdx.and.nbe.com.eg com.ofss.obdx.and.nbe.com.eg"
su -c "magisk --denylist add com.ofss.obdx.and.nbe.com.eg com.ofss.obdx.and.nbe.com.eg:playcore_missing_splits_activity"
su -c "magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile"
su -c "magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile:gib"
su -c "magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile:pushservice"
su -c "magisk --denylist add sa.com.stcpay sa.com.stcpay"
su -c "magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat"
su -c "magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat:container"
su -c "magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat:pushservice"
su -c "magisk --denylist add com.orange.mobinilandme com.orange.mobinilandme"
su -c "magisk --denylist add com.orange.mobinilandme com.orange.mobinilandme:container"
su -c "magisk --denylist add com.TE.WEWallet com.TE.WEWallet"
su -c "magisk --denylist add com.emeint.android.myservices com.emeint.android.myservices"
su -c "magisk --denylist add sa.gov.moi sa.gov.moi"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:plugin"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:GP6Service"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:imsdk_inner_webview"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:intl_inner_webview"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:networkDetector"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:playcore_missing_splits_activity"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:plugin"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:playcore_missing_splits_activity"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:networkDetector"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:intl_inner_webview"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:imsdk_inner_webview"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:GP6Service"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:GP6Service"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:imsdk_inner_webview"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:networkDetector"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:plugin"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:playcore_missing_splits_activity"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:intl_inner_webview"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:GP6Service"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:imsdk_inner_webview"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:networkDetector"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:intl_inner_webview"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:plugin"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:playcore_missing_splits_activity"
su -c "magisk --denylist add sa.gov.moia.es.amer sa.gov.moia.es.amer"
su -c "magisk --denylist add com.tcs.nim com.tcs.nim"
su -c "magisk --denylist add com.tcs.nim com.tcs.nim:container"
su -c "magisk --denylist add com.kimchangyoun.rootbeerFresh.sample com.kimchangyoun.rootbeerFresh.sample"
su -c "magisk --denylist add com.scottyab.rootbeer.sample com.scottyab.rootbeer.sample"
su -c "magisk --denylist add com.fawry.myfawry com.fawry.myfawry"
su -c "magisk --denylist add com.fawry.myfawry com.fawry.myfawry:remote"
su -c "magisk --denylist add com.orange.eg.money com.orange.eg.money"
su -c "magisk --denylist add com.orange.eg.money com.orange.eg.money:error_activity"
su -c "magisk --denylist add com.orange.eg.money com.orange.eg.money:container"
su -c "magisk --denylist add krypton.tbsafetychecker krypton.tbsafetychecker"
su -c "magisk --denylist add com.competitivetechnology.tvtc com.competitivetechnology.tvtc"
su -c "magisk --denylist add com.competitivetechnology.tvtc com.competitivetechnology.tvtc:remote"
su -c "magisk --denylist add sa.alfursan.it.apps.ontimeplus sa.alfursan.it.apps.ontimeplus"
su -c "magisk --denylist add com.mosques_managment.moia.gov.sa com.mosques_managment.moia.gov.sa"
su -c "magisk --denylist add com.mosques_managment.moia.gov.sa com.mosques_managment.moia.gov.sa:pushservice"
su -c "magisk --denylist add com.google.android.ims com.google.android.ims"
su -c "magisk --denylist add com.google.android.ims com.google.android.ims:crash_report"
su -c "magisk --denylist add com.google.android.ims com.google.android.ims:primes_lifeboat"

# End Hide App Script ⭐
