#!/system/bin/sh
# Kill Google Play All Services ✅

if [ "$USER" != "root" -a "$(whoami 2>/dev/null)" != "root" ]; then
  echo "killpi: need root permissions";
  exit 1;
fi;

killall com.google.android.gms.unstable;
killall com.android.vending;

sleep 1
if pgrep com.google.android.gms.unstable; then
  echo "Forcibly killing com.google.android.gms.unstable"
  pkill -9 com.google.android.gms.unstable
fi

if pgrep com.android.vending; then
  echo "Forcibly killing com.android.vending"
  pkill -9 com.android.vending
fi
# Check
conflict_packages="net.maxters.droid.playi"
found=0
for pkg in $conflict_packages; do
  if grep -q "$pkg" /data/system/packages.list; then 
    [ $found -eq 0 ] && echo
    found=1

    echo "$pkg" > /dev/null

    if [ "$pkg" = "net.maxters.droid.playi" ]; then
      echo " $pkg" > /dev/null
      pm uninstall --user 0 "$pkg" > /dev/null
    fi
  fi
done
[ $found -eq 1 ] && echo
echo
sleep 4
nohup am start -n "gr.nikolasspyr.integritycheck/gr.nikolasspyr.integritycheck.MainActivity" >/dev/null 2>&1 &
sleep_pause