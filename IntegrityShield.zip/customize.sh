#!/system/bin/sh

# =========================
# Telegram : @MRootSu 🫰♥️
# =========================

if ! $BOOTMODE; then
    ui_print
    ui_print
    abort
fi

# android < 8 not supported
[ "$API" -lt 26 ] && abort "❌ Android < 8.0 is not supported!"

# Android
if [ "$API" -ge 34 ]; then
    ui_print
fi

check_zygisk() {
    local MAGISK_DIR="/data/adb/magisk"
    local MSG=" ❌ Zygisk is not enabled.\n- Enable Zygisk in Magisk settings\n- Install ZygiskNext or ReZygisk module"

    [ -d /data/adb/modules/zygisksu ] || [ -d /data/adb/modules/rezygisk ] && return 0

    if [ -d "$MAGISK_DIR" ]; then
        local zygisk_status
        zygisk_status=$(magisk --sqlite "SELECT value FROM settings WHERE key='zygisk';")
        [ "$zygisk_status" = "value=1" ] || abort "$MSG"
    else
        abort "$MSG"
    fi
}

check_zygisk

[ -d /data/adb/modules/safetynet-fix ] && {
    ui_print "⚠ safetynet-fix is incompatible and will be removed on next reboot."
    touch /data/adb/modules/safetynet-fix/remove
}
[ -d /data/adb/modules/playcurl ] && ui_print "⚠ playcurl may overwrite the fingerprint with invalid data."
[ -d /data/adb/modules/MagiskHidePropsConf ] && ui_print "⚠ MagiskHidePropsConf may cause issues with PIF."

#TrickyStore
TRICKYSTORE_PATH="/data/adb/modules/tricky_store"
[ ! -d "$TRICKYSTORE_PATH" ] && abort "❌ Tricky Store not detected!\nInstall it first."
ui_print 

# Start Bootloader&Spoofer Script ⭐
 Start Random KeyBox By @MRootSu ⭐
unzip -o "$ZIPFILE" 'zygisk/*' -d "$MODPATH/zygisk" > /dev/null 2>&1

if [ -f "/data/adb/tricky_store/target.txt" ]; then
  backup_file "$CONFIG_DIR/target.txt"
  rm "/data/adb/tricky_store/target.txt"
fi
random_keybox=$(find "$MODPATH/zygisk" -type f -name "*.x" | shuf -n 1)
if [ -z "$random_keybox" ]; then
    abort "Error: No .x files found"
    exit 1
fi
cp "$random_keybox" "/data/adb/tricky_store/target.txt"

# Start Random KeyBox By @MRootSu ⭐
 Start Random KeyBox By @MRootSu ⭐
unzip -o "$ZIPFILE" 'zygisk/*' -d "$MODPATH/zygisk" > /dev/null 2>&1

if [ -f "/data/adb/tricky_store/keybox.xml" ]; then
  backup_file "$CONFIG_DIR/keybox.xml"
  rm "/data/adb/tricky_store/keybox.xml"
fi
random_keybox=$(find "$MODPATH/zygisk" -type f -name "*.@MRootSu" | shuf -n 1)
if [ -z "$random_keybox" ]; then
    abort "Error: No .@MRootSu files found"
    exit 1
fi
cp "$random_keybox" "/data/adb/tricky_store/keybox.xml" 

su -c killall com.google.android.gms
su -c killall com.google.android.gms.unstable

# Copy security_patch
cp -f "$MODPATH/security_patch.txt" /data/adb/tricky_store/

# Improved TrickyStore
OLD_JSON="/data/adb/modules/playintegrityfix/pif.json"
NEW_JSON="$MODPATH/pif.json"

for key in spoofProvider spoofProps spoofSignature DEBUG spoofVendingSdk; do
    grep -q "$key" "$OLD_JSON" || continue
    if grep -q "\"$key\": true" "$OLD_JSON"; then
        sed -i "s/\"$key\": .*/\"$key\": true,/" "$NEW_JSON"
    else
        sed -i "s/\"$key\": .*/\"$key\": false,/" "$NEW_JSON"
    fi
done
sed -i ':a;N;$!ba;s/\,\n\}/\n\}/g' "$NEW_JSON"

# Restore customized pif.json
[ -f /data/adb/pif.json ] && mv -f /data/adb/pif.json /data/adb/pif.json.old && ui_print "  📂 Backup pif.json preserved."

# Final
chmod +x "$MODPATH/action.sh"
ui_print "- ⭐ This Modules Developers By @MRootSu "
ui_print "- 🥊 Built-In BusyBox 🛠️"
ui_print "- 🔥 Device Integrity ✅"
ui_print "- 🎭 Add New KeyBox 🛸"
ui_print "- 💢 Hide Apps Auto ⭐"
ui_print "- ✂️ System AdBlock 🚫"
ui_print "- 📞 Telegram : @MRootSu "