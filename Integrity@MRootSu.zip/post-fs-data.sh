# @tryigitx cn rom
resetprop ro.boot.hwc CN
resetprop ro.boot.hwlevel MP
resetprop gsm.sim.operator.iso-country cn
resetprop gsm.operator.iso-country cn
resetprop persist.radio.skhwc_matchres "SKU:CN HWC:CN"

# @tryigitx -will only work on vip drivers-
if [ -d "/data/adb/magisk/" ]; then
resetprop ro.zygote zygote64
resetprop dalvik.vm.dex2oat64.enabled true
resetprop ro.vendor.mi_fake_32bit_support true
resetprop ro.vendor.mi_support_zygote32_lazyload true
fi

# Credit @tryigitx cn rom
while [ "$(getprop sys.boot_completed)" != 1 ]; do
    sleep 10
done
resetprop -n persist.radio.skhwc_matchres "SKU:CN HWC:CN"
resetprop -n persist.radio.dynamic_hwc "china"
resetprop -n gsm.operator.iso-country "cn"
resetprop -n ro.boot.hwlevel "MP"
resetprop -n ro.boot.hwc "CN"
done