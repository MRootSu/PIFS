echo "
             اللهم صّلِ وسَلّمْ عَلۓِ نَبِيْنَامُحَمد ﷺ
╗────────────────────────────────────────╔
      King 👑 Of The Root│Telegram : @MRootSu
╝────────────────────────────────────────╚
"
sleep 2
echo "      ⚓ Upgrading KeyBox.xml By @MRootSu 🛡️"
ping -w 1 google.com &>/dev/null
if [ $? -ne 0 ]; then
    echo "   مرحبآ انا مستر روت ⛅ الرجاء التأكد من حاله الإنترنت لديك ✂️ "
    sleep 2
    exit 1
fi

# Download Strong File By @MRootSu ✅"
        curl -o /data/adb/tricky_store/keybox.xml https://raw.githubusercontent.com/MRootSu/PIFS/refs/heads/main/KEY.MRootSu   
        curl -o /sdcard/hosts1 https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/porn/hosts
        curl -o /sdcard/hosts2 https://raw.githubusercontent.com/hagezi/dns-blocklists/main/hosts/ultimate-compressed.txt
        curl -o /data/adb/tricky_store/target.txt https://raw.githubusercontent.com/MRootSu/PIFS/refs/heads/main/target.txt

echo "   تم صنع الاسكريبت بواسطه [ مستر روت ] ⛅ "
{
    for j_cole in /system/etc/hosts /sdcard/hosts1 /sdcard/hosts2 ; do
        cat $j_cole
        echo ""
    done
} | sort | uniq > /data/adb/modules/playintegrityfix/system/etc/hosts

# let's see if the file was downloaded or not.
if [ ! -f "/sdcard/hosts1" ]; then
    echo "       Looks like there is a problem with some weapons, maybe check your internet connection?"
else 
    echo " Everthing is Fine Now, Enjoy 😉"
    rm /sdcard/hosts1
    rm /sdcard/hosts2
    sleep 8
fi
nohup am start -a android.intent.action.VIEW -d https://t.me/MRootOnline >/dev/null 2>&1 &
