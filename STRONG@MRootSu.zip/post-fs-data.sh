MODDIR=${0%/*}

# @MRootSu cn rom
resetprop ro.boot.hwc CN
resetprop ro.boot.hwlevel MP
resetprop gsm.sim.operator.iso-country cn
resetprop gsm.operator.iso-country cn
resetprop persist.radio.skhwc_matchres MATCH

# @MRootSu -will only work on vip drivers-
resetprop ro.zygote zygote64
resetprop dalvik.vm.dex2oat64.enabled true
resetprop ro.vendor.mi_fake_32bit_support true
resetprop ro.vendor.mi_support_zygote32_lazyload true