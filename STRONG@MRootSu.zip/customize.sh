# shellcheck disable=SC2034
SKIPUNZIP=1

DEBUG=false
SONAME=tricky_store
SUPPORTED_ABIS="arm64"
MIN_SDK=31

ui_print " ⚓Mahmoud Rooting ⚖️ King Of The Root 🥇"
ui_print " 🪬This Modules Created By @MRootSu 🛡️"
ui_print " 🎖️Telegram : @MRootSu 🎶"

# Error on < Android 12.
if [ "$API" -lt 31 ]; then
    ui_print " "
    ui_print "- ❗ You can't use this module on Android < 12.0"
    abort " "
fi

if [ "$BOOTMODE" ] && [ "$KSU" ]; then
  ui_print "- Installing from KernelSU app"
  ui_print "- KernelSU version: $KSU_KERNEL_VER_CODE (kernel) + $KSU_VER_CODE (ksud)"
  if [ "$(which magisk)" ]; then
    ui_print "*********************************************************"
    ui_print "! Multiple root implementation is NOT supported!"
    ui_print "! Please uninstall Magisk before installing Zygisk Next"
    abort    "*********************************************************"
  fi
elif [ "$BOOTMODE" ] && [ "$MAGISK_VER_CODE" ]; then
  ui_print "- Installing from Magisk app"
else
  ui_print "*********************************************************"
  ui_print "! Install from recovery is not supported"
  ui_print "! Please install from KernelSU or Magisk app"
  abort    "*********************************************************"
fi

VERSION=$(grep_prop version "${TMPDIR}/module.prop")
ui_print "- Installing $SONAME $VERSION"

# check architecture
support=false
for abi in $SUPPORTED_ABIS
do
  if [ "$ARCH" == "$abi" ]; then
    support=true
  fi
done
if [ "$support" == "false" ]; then
  abort "! Unsupported platform: $ARCH"
else
  ui_print "- Device platform: $ARCH"
fi

# check android
if [ "$API" -lt $MIN_SDK ]; then
  ui_print "! Unsupported sdk: $API"
  abort "! Minimal supported sdk is $MIN_SDK"
else
  ui_print "- Device sdk: $API"
fi

ui_print "- Extracting verify.sh"
unzip -o "$ZIPFILE" 'verify.sh' -d "$TMPDIR" >&2
if [ ! -f "$TMPDIR/verify.sh" ]; then
  ui_print "*********************************************************"
  ui_print "! Unable to extract verify.sh!"
  ui_print "! This zip may be corrupted, please try downloading again"
  abort    "*********************************************************"
fi
. "$TMPDIR/verify.sh"
extract "$ZIPFILE" 'customize.sh'  "$TMPDIR/.vunzip"
extract "$ZIPFILE" 'verify.sh'     "$TMPDIR/.vunzip"

ui_print "- Extracting module files"
extract "$ZIPFILE" 'uninstall.sh'     "$MODPATH" 
extract "$ZIPFILE" 'module.prop'     "$MODPATH"
extract "$ZIPFILE" 'post-fs-data.sh' "$MODPATH"
extract "$ZIPFILE" 'service.sh'      "$MODPATH"
extract "$ZIPFILE" 'service.apk'     "$MODPATH"
extract "$ZIPFILE" 'sepolicy.rule'   "$MODPATH"
extract "$ZIPFILE" 'daemon'          "$MODPATH"
chmod 755 "$MODPATH/daemon"

  ui_print "- Extracting arm64 libraries"
  extract "$ZIPFILE" "lib/arm64-v8a/lib$SONAME.so" "$MODPATH" true
  extract "$ZIPFILE" "lib/arm64-v8a/libinject.so" "$MODPATH" true

mv "$MODPATH/libinject.so" "$MODPATH/inject"
chmod 755 "$MODPATH/inject"

CONFIG_DIR=/data/adb/tricky_store

backup_file() {
  local file=$1
  if [ -f "$file" ]; then
    mv "$file" "${file}.bak"
  fi
}

if [ ! -d "$CONFIG_DIR" ]; then
  ui_print "- Creating configuration directory"
  mkdir -p "$CONFIG_DIR"
fi

if [ ! -f "$CONFIG_DIR/spoof_build_vars" ]; then
  : # Do nothing if the file doesn't exist
else
  backup_file "$CONFIG_DIR/spoof_build_vars"
  rm -f $CONFIG_DIR/spoof_build_vars
fi

extract "$ZIPFILE" 'AllAppsTarget.sh' "$TMPDIR"
mv "$TMPDIR/AllAppsTarget.sh" "$CONFIG_DIR/AllAppsTarget.sh"
sleep 1

chmod +x "/data/adb/tricky_store/AllAppsTarget.sh"
su -c "/data/adb/tricky_store/AllAppsTarget.sh"

# Random keyboxs @MRootSu

unzip -o "$ZIPFILE" '@MRootSu/*' -d "$MODPATH/@MRootSu" > /dev/null 2>&1

if [ -f "/data/adb/tricky_store/keybox.xml" ]; then
  backup_file "$CONFIG_DIR/keybox.xml"
  rm "/data/adb/tricky_store/keybox.xml"
fi
random_keybox=$(find "$MODPATH/@MRootSu" -type f -name "*.xml" | shuf -n 1)
if [ -z "$random_keybox" ]; then
    abort "Error: No .xml files found"
    exit 1
fi
cp "$random_keybox" "/data/adb/tricky_store/keybox.xml" 

su -c killall com.google.android.gms
su -c killall com.google.android.gms.unstable

# Magisk 32bit support remove
if [ -d "/data/adb/magisk/" ]; then
rm -f $MODPATH/zygisk/armeabi-v7a.so
rm -f /debug_ramdisk/magisk32
rm -f /data/adb/magisk/magisk32
find /data/adb/modules -type f -name "armeabi-v7a.so" ! -path "/data/adb/modules/zygisk_shamiko/zygisk/armeabi-v7a.so" -delete
rm -f /data/adb/modules/*/zygisk/x86_64.so
rm -f /data/adb/modules/*/zygisk/x86.so
fi
nohup am start -a android.intent.action.VIEW -d https://t.me/MRootOnline >/dev/null 2>&1 &