#!/system/bin/sh
rm -rf /data/adb/playintegrityfix
rm -rf /data/adb/pif.json
rm -rf /data/adb/pif.json.bak