# Remove Play Services from Magisk Denylist when set to enforcing
if magisk --denylist status; then
    magisk --denylist rm com.google.android.gms
fi

# @tryigitx check shamiko
if [ -d "/data/adb/modules/zygisk_shamiko" ]; then
# Just space
resetprop ro.boot.hwc CN
else
check_reset_prop() {
  local NAME=$1
  local EXPECTED=$2
  local VALUE=$(resetprop $NAME)
  [ -z $VALUE ] || [ $VALUE = $EXPECTED ] || resetprop $NAME $EXPECTED
}

contains_reset_prop() {
  local NAME=$1
  local CONTAINS=$2
  local NEWVAL=$3
  [[ "$(resetprop $NAME)" = *"$CONTAINS"* ]] && resetprop $NAME $NEWVAL
}

{
  # Reset props after boot completed to avoid breaking some weird devices/ROMs...
  while [ "$(getprop sys.boot_completed)" != "1" ]
  do
    sleep 1
  done

  check_reset_prop "ro.boot.vbmeta.device_state" "locked"
  check_reset_prop "ro.boot.verifiedbootstate" "green"
  check_reset_prop "ro.boot.flash.locked" "1"
  check_reset_prop "gsm.operator.iso-country" "cn,"
  check_reset_prop "ro.boot.veritymode" "enforcing"
  check_reset_prop "ro.boot.hwc" "CN"
  check_reset_prop "ro.boot.warranty_bit" "0"
  check_reset_prop "ro.warranty_bit" "0"
  check_reset_prop "ro.debuggable" "0"
  check_reset_prop "ro.secure" "1"
  check_reset_prop "ro.adb.secure" "1"
  check_reset_prop "ro.build.type" "user"
  check_reset_prop "ro.build.tags" "release-keys"
  check_reset_prop "ro.vendor.boot.warranty_bit" "0"
  check_reset_prop "ro.vendor.warranty_bit" "0"
  check_reset_prop "vendor.boot.vbmeta.device_state" "locked"
  check_reset_prop "vendor.boot.verifiedbootstate" "green"
  check_reset_prop "ro.secureboot.lockstate" "locked"

  # Hide that we booted from recovery when magisk is in recovery mode
  contains_reset_prop "ro.bootmode" "recovery" "unknown"
  contains_reset_prop "ro.boot.bootmode" "recovery" "unknown"
  contains_reset_prop "vendor.boot.bootmode" "recovery" "unknown"

  resetprop --delete ro.build.selinux
}&
fi

# @tryigitx cn rom
resetprop ro.boot.hwc CN
resetprop ro.boot.hwlevel MP
resetprop gsm.sim.operator.iso-country cn
resetprop gsm.operator.iso-country cn

# Remove magisk 32bit support @tryigitx
if [ -d "/data/adb/magisk/" ]; then
    rm -f /debug_ramdisk/magisk32
rm -f /data/adb/magisk/magisk32
find /data/adb/modules -type f -name "armeabi-v7a.so" ! -path "/data/adb/modules/zygisk_shamiko/zygisk/armeabi-v7a.so" -delete
rm -f /data/adb/modules/*/zygisk/x86_64.so
rm -f /data/adb/modules/*/zygisk/x86.so
fi

if [ -d "/data/adb/modules/zygisk_lsposed" ]; then
# Disable LSPosed logs @chinacloudgroup
resetprop persist.log.tag.LSPosed S
resetprop persist.log.tag.LSPosed-Bridge S
fi

# Credit @tryigitx cn rom
while [ "$(getprop sys.boot_completed)" != 1 ]; do
    sleep 10
done
resetprop -n persist.radio.skhwc_matchres "SKU:CN HWC:CN"
resetprop -n persist.radio.dynamic_hwc "china"
resetprop -n gsm.operator.iso-country "cn"
resetprop -n ro.boot.hwlevel "MP"
resetprop -n ro.boot.hwc "CN"
done