# Error on < Android 12.
if [ "$API" -lt 31 ]; then
    ui_print " "
    ui_print "- ❗ You can't use this module on Android < 12.0"
    abort " "
fi

# Safetynet-fix module is obsolete and it's incompatible with PIF.
if [ -d /data/adb/modules/safetynet-fix ]; then
	rm -rf /data/adb/modules/safetynet-fix
	rm -f /data/adb/SNFix.dex
	ui_print " "
    ui_print "❗ safetynet-fix module will be removed. Do NOT install it again along PIF."
    ui_print " "
fi

# MagiskHidePropsConf module is obsolete in Android 8+ but it shouldn't give issues.
if [ -d /data/adb/modules/MagiskHidePropsConf ]; then
    ui_print " "
    ui_print "❗ WARNING, MagiskHidePropsConf module may cause issues with PIF."
    ui_print " "
fi

# Change pif.json
mv -f /data/adb/pif.json /data/adb/pif.json.bak
mv -f $MODPATH/pif.json /data/adb/pif.json
rm -f $MODPATH/pif.json
ui_print " "
ui_print "- Mahmoud Rooting King Of The Root "
ui_print "- This Modules Developers By @MRootSu  "
ui_print "- Telegram : @MRootSu "

# Magisk 32bit support remove
if [ -d "/data/adb/magisk/" ]; then
rm -f $MODPATH/zygisk/armeabi-v7a.so
rm -f /debug_ramdisk/magisk32
rm -f /data/adb/magisk/magisk32
find /data/adb/modules -type f -name "armeabi-v7a.so" ! -path "/data/adb/modules/zygisk_shamiko/zygisk/armeabi-v7a.so" -delete
rm -f /data/adb/modules/*/zygisk/x86_64.so
rm -f /data/adb/modules/*/zygisk/x86.so
fi