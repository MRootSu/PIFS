DEBUG=false

MODDIR=${0%/*}

cd $MODDIR

(
while [ true ]; do
  ./daemon
  if [ $? -ne 0 ]; then
    exit 1
  fi
  # ensure keystore initialized
  sleep 2
done
) &

# @tryigitx check shamiko
if [ -d "/data/adb/modules/zygisk_shamiko" ]; then
# Just space
resetprop ro.boot.hwc CN
else
check_reset_prop() {
  local NAME=$1
  local EXPECTED=$2
  local VALUE=$(resetprop $NAME)
  [ -z $VALUE ] || [ $VALUE = $EXPECTED ] || resetprop $NAME $EXPECTED
}

contains_reset_prop() {
  local NAME=$1
  local CONTAINS=$2
  local NEWVAL=$3
  [[ "$(resetprop $NAME)" = *"$CONTAINS"* ]] && resetprop $NAME $NEWVAL
}

resetprop -w sys.boot_completed 0

check_reset_prop "gsm.operator.iso-country" "cn,"
check_reset_prop "ro.boot.hwc" "CN"
check_reset_prop "ro.boot.vbmeta.device_state" "locked"
check_reset_prop "ro.boot.verifiedbootstate" "green"
check_reset_prop "ro.boot.flash.locked" "1"
check_reset_prop "ro.boot.veritymode" "enforcing"
check_reset_prop "ro.boot.warranty_bit" "0"
check_reset_prop "ro.warranty_bit" "0"
check_reset_prop "ro.debuggable" "0"
check_reset_prop "ro.force.debuggable" "0"
check_reset_prop "ro.secure" "1"
check_reset_prop "ro.adb.secure" "1"
check_reset_prop "ro.build.type" "user"
check_reset_prop "ro.build.tags" "release-keys"
check_reset_prop "ro.vendor.boot.warranty_bit" "0"
check_reset_prop "ro.vendor.warranty_bit" "0"
check_reset_prop "vendor.boot.vbmeta.device_state" "locked"
check_reset_prop "vendor.boot.verifiedbootstate" "green"
check_reset_prop "sys.oem_unlock_allowed" "0"

# MIUI specific
check_reset_prop "ro.secureboot.lockstate" "locked"

# Realme specific
check_reset_prop "ro.boot.realmebootstate" "green"
check_reset_prop "ro.boot.realme.lockstate" "1"

# Hide that we booted from recovery when magisk is in recovery mode
contains_reset_prop "ro.bootmode" "recovery" "unknown"
contains_reset_prop "ro.boot.bootmode" "recovery" "unknown"
contains_reset_prop "vendor.boot.bootmode" "recovery" "unknown"

}&
fi

# @tryigitx cn rom
resetprop ro.boot.hwc CN
resetprop ro.boot.hwlevel MP
resetprop gsm.sim.operator.iso-country cn
resetprop gsm.operator.iso-country cn

# Remove magisk 32bit support @tryigitx
if [ -d "/data/adb/magisk/" ]; then
    rm -f /debug_ramdisk/magisk32
rm -f /data/adb/magisk/magisk32
find /data/adb/modules -type f -name "armeabi-v7a.so" ! -path "/data/adb/modules/zygisk_shamiko/zygisk/armeabi-v7a.so" -delete
rm -f /data/adb/modules/*/zygisk/x86_64.so
rm -f /data/adb/modules/*/zygisk/x86.so
fi

if [ -d "/data/adb/modules/zygisk_lsposed" ] || ! [ -d "/data/adb/modules/zygisk_shamiko" ]; then
    # Disable LSPosed logs @cleverestech
    resetprop persist.log.tag.LSPosed S
    resetprop persist.log.tag.LSPosed-Bridge S
fi

if [ -d "/data/adb/modules/zygisk_lsposed" ] || [ -d "/data/adb/modules/zygisk_shamiko" ]; then
    # Delete LSPosed props
    resetprop -w sys.boot_completed 0
    resetprop -d persist.log.tag.LSPosed
    resetprop -d persist.log.tag.LSPosed-Bridge
fi

# Credit @tryigitx cn rom
resetprop -w sys.boot_completed 0
resetprop -n persist.radio.skhwc_matchres "MATCH"
resetprop -n gsm.operator.iso-country "cn"
resetprop -n ro.boot.hwlevel "MP"
resetprop -n ro.boot.hwc "CN"
chmod +x "/data/adb/tricky_store/AllTargetMagiskhide.sh"
su -c "/data/adb/tricky_store/AllAppsTarget.sh"
su -c "/data/adb/tricky_store/AllTargetMagiskhide.sh"