echo "
             اللهم صّلِ وسَلّمْ عَلۓِ نَبِيْنَامُحَمد ﷺ
╗────────────────────────────────────────╔
      King 👑 Of The Root│Telegram : @MRootSu
╝────────────────────────────────────────╚
"
sleep 2
echo   "⚓ Upgrading 🎗️KeyBox🎗️PIF🎗️Strong🎗️Target🎗️ 🛡️"
ping -w 1 google.com &>/dev/null
if [ $? -ne 0 ]; then
    echo "   مرحبآ انا مستر روت ⛅ الرجاء التأكد من حاله الإنترنت لديك ✂️ "
    sleep 2
    exit 1
fi

# Download Strong File By @MRootSu ✅"
        curl -o /data/adb/tricky_store/keybox.xml https://raw.githubusercontent.com/MRootSu/IntegrityShield/refs/heads/main/KEY.MRootSu
        curl -o /data/adb/pif.json https://raw.githubusercontent.com/MRootSu/IntegrityShield/refs/heads/main/pif.json
        curl -o /data/adb/tricky_store/target.txt https://raw.githubusercontent.com/MRootSu/IntegrityShield/refs/heads/main/target.txt
echo
echo
echo
echo " ⭐ سيتم تحويلك تلقائى الى القناة الخاصه بنا 🥇"
sleep 4
echo
echo
echo
echo "      📲 Successfully Updating All Done! 💯"
sleep 1
nohup am start -a android.intent.action.VIEW -d https://t.me/MRootOnline >/dev/null 2>&1 &
echo
echo
echo "            🇦🇪🇧🇭🇪🇬🇶🇦🇮🇶🇯🇴🇱🇧🇰🇼🇱🇾🇾🇪🇵🇸🇸🇦🇸🇩 "
echo
echo " 🫰 تم صنع الاسكريبت بكل الحب 💌 بواسطة [ مستر روت ] ⛅ "
echo
echo
sleep_pause